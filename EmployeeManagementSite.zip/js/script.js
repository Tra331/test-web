document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const employeeList = document.getElementById('employees');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const name = form.name.value.trim();
        const position = form.position.value.trim();

        if (name && position) {
            const li = document.createElement('li');
            li.textContent = `${name} - ${position}`;
            employeeList.appendChild(li);
            form.reset();
        }
    });
});
